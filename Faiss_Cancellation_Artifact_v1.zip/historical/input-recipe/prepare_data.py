import sys, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/h5site'))
import numpy as np
import h5py
from bootstrap import sha,save

def write_arrays(name,base,query,ids,source):
    base=np.ascontiguousarray(base,dtype='float32'); query=np.ascontiguousarray(query,dtype='float32')
    assert base.shape[0]==75000 and query.shape[0]==2049
    assert np.isfinite(base).all() and np.isfinite(query).all()
    paths={}
    for suffix,a in [('base',base),('query',query),('sample_ids',ids)]:
        p=ROOT/'data'/f'{name}_{suffix}.npy'
        with p.open('xb') as f: np.save(f,a)
        paths[suffix]={'path':str(p),'sha256':sha(p),'array_sha256':hashlib.sha256(a.tobytes()).hexdigest(),'shape':list(a.shape),'dtype':str(a.dtype)}
    # Native harness uses simple row-major fvecs, identical float32 bytes.
    for suffix,a in [('base',base),('query',query)]:
        p=ROOT/'data'/f'{name}_{suffix}.fvecs'
        packed=np.empty((len(a),a.shape[1]+1),dtype='float32'); packed[:,0]=np.array([a.shape[1]],dtype='int32').view('float32')[0]; packed[:,1:]=a
        with p.open('xb') as f: f.write(packed.tobytes())
        paths[suffix+'_fvecs']={'sha256':sha(p),'bytes':p.stat().st_size}
    return {'name':name,'source':source,'files':paths}

def main():
    datasets=[]
    old=ROOT.parent/'定题冲刺_20261023/data'
    full=np.load(old/'sift100k_base.npy'); ids=np.random.default_rng(20261024).choice(len(full),75000,replace=False)
    datasets.append(write_arrays('sift75k',full[ids],np.load(old/'sift_query.npy')[2048:4097],ids,{'base_sha256':sha(old/'sift100k_base.npy'),'query_sha256':sha(old/'sift_query.npy'),'query_slice':[2048,4097],'note':'Nested SIFT subset, not independent distribution'}))
    p=ROOT/'tools/glove_verified.hdf5'
    with h5py.File(p,'r') as f:
        ids=np.random.default_rng(20261024).choice(len(f['train']),75000,replace=False)
        # h5py requires sorted fancy indexing; restore frozen sample order.
        order=np.argsort(ids); sampled=np.asarray(f['train'][ids[order]],dtype='float32'); base=sampled[np.argsort(order)]
        query=np.asarray(f['test'][:2049],dtype='float32')
        before={'train_shape':list(f['train'].shape),'test_shape':list(f['test'].shape),'attributes':{k:str(v) for k,v in f.attrs.items()},'sha256':sha(p)}
        for a in [base,query]:
            norm=np.linalg.norm(a.astype('float64'),axis=1)
            assert (norm>0).all()
            a[:]=(a.astype('float64')/norm[:,None]).astype('float32')
        before['transform']='float64 row norm and division, cast float32; squared L2 on these stored vectors'
        datasets.append(write_arrays('glove75k',base,query,ids,before))
    save(ROOT/'data/manifest.json',datasets)
    print(json.dumps([{d['name']:d['files']['base']['shape']} for d in datasets]),flush=True)
if __name__=='__main__': main()
