"""One frozen strategy process; uses the accepted measurement/quality definitions."""
from pathlib import Path
import datetime,hashlib,json,os,platform,sys,time

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(manifest_path,task_id,output,attempt):
    if platform.system()!='Linux':raise RuntimeError('Actual Linux worker required')
    path=Path(manifest_path).resolve();m=json.loads(path.read_text('utf-8'));root=path.parent
    engineering=m.get('status')=='ENGINEERING_ONLY' and m.get('schema')=='paper4-ccpe-bridge-engineering-1'
    if not engineering and (m.get('status')!='FROZEN' or m.get('schema')!='paper4-ccpe-bridge-frozen-1'):raise ValueError('A distinct frozen bridge or explicit engineering manifest is required')
    if not engineering:
        from .prepare import validated_freeze
        m=validated_freeze(path)
    for item in m['identity_files']:
        p=root/item['path']
        if sha(p)!=item['sha256']:raise ValueError('Frozen identity mismatch: '+str(p))
    spec=next(t for t in m['tasks'] if t['task_id']==task_id);runtime=m['runtime'];inputs=m['inputs'][spec['dataset']]
    os.sched_setaffinity(0,set(m['resources']['search_cpus']))
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[name]='4'
    os.environ['OMP_DYNAMIC']='FALSE';os.environ['OMP_NESTED']='FALSE';os.environ['OMP_MAX_ACTIVE_LEVELS']='1'
    import numpy as np
    import faiss
    if any(hasattr(faiss,name) for name in ['runtime_identity','set_branch_policy','begin_request']):raise ValueError('Research-patched Faiss is not permitted')
    declared_module=(root/runtime['module_file']).resolve()
    if Path(faiss.__file__).resolve()!=declared_module:raise ValueError('Unexpected Python module')
    maps=Path('/proc/self/maps').read_text('utf-8')
    loaded={line.split(None,5)[-1] for line in maps.splitlines() if len(line.split(None,5))==6}
    receipt=json.loads((root/runtime['build_receipt']).read_text('utf-8'))
    required=[(root/name).resolve() for name in runtime['mapped_files']]
    required.extend(Path(x['path']).resolve() for x in receipt['dependencies']
                    if 'openblas' in Path(x['path']).name.lower() or 'libgomp' in Path(x['path']).name or 'libomp.' in Path(x['path']).name)
    for library in required:
        if str(library) not in loaded:raise ValueError('Expected runtime library is not mapped: '+str(library))
    from .backend import Backend,CallbackBridge
    from v3tools.measurement_helper import MeasurementHelper
    from v3tools.runner import measure
    from v3tools.quality import check_result
    index=faiss.read_index(str(root/inputs['index']));index.nprobe=spec['nprobe'];index.parallel_mode=0
    if int(index.d)!=inputs['dimension'] or int(index.ntotal)!=75000 or int(index.nlist)!=100:raise ValueError('Frozen index dimensions differ')
    queries=np.load(root/inputs['queries']);base=np.load(root/inputs['base'],mmap_mode='r')
    if queries.shape!=(2049,index.d) or base.shape!=(75000,index.d):raise ValueError('Historical fixed input shape')
    ref=np.load(root/inputs['references'][str(spec['nprobe'])+'/'+str(spec['nq'])])
    faiss.omp_set_num_threads(4);faiss.cvar.distance_compute_blas_threshold=128000;faiss.cvar.distance_compute_blas_query_bs=4096
    cb=CallbackBridge(root/runtime['callback']);helper=MeasurementHelper(root/runtime['helper'],runtime['helper_sha256'])
    identity=dict(build='fixed upstream + R1 sync-only + external C/P',callback=cb.identity,threshold=spec['threshold'],branch_observation='source_prediction_only',official_wheel=False)
    backend=Backend(index,faiss,cb,helper,m['resources']['producer_cpu'],identity)
    policy='outer16' if spec['arm']=='outer16_default' else 'native0' if spec['arm']=='n0_default' else 'native3'
    cell=dict(module=spec['module'],dataset=spec['dataset'],nprobe=spec['nprobe'],nq=spec['nq'],cpu=4,policy=policy,state=spec['state'],trace='off',mode=3 if policy=='native3' else 0,guard='long_'+spec['state'],threshold=spec['threshold'],branch_policy='default',deadline_ms=20,planned_arrival_ms=20,deadline_api='absolute',producer='independent_native',logging='deferred',input_pool='historical',branch='source_prediction_only')
    task=dict(spec,cell=cell,block_id=spec['block'],joint_attempt_id=str(attempt),joint_window_id=spec['panel_id'],long_deadline_ms=120000)
    out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists():raise ValueError('Output exists; do not overwrite an attempted task')
    phase='warmup';npz_paths=[]
    def quality(old,successor):
        valid={};arrays={}
        for name,result,q in [('old',old,queries[:spec['nq']]),('successor',successor,queries[[2048]])]:
            if result is None:valid[name]=None;continue
            distances,ids=result
            valid[name]=check_result(base,q,distances,ids,ref[name+'_0_distances'],ref[name+'_0_actual'],rtol=1e-5,atol=1e-5,exact_actual=spec['dataset']=='SIFT75k')
            arrays[name+'_distances']=distances;arrays[name+'_ids']=ids
        if arrays:
            target=out.with_name(out.stem+'_'+phase+'_outputs.npz');np.savez(target,**arrays);npz_paths.append(dict(path=target.name,sha256=sha(target)))
        return valid
    def record(case):
        row=measure(task,case,backend,queries[:spec['nq']],queries[[2048]],quality)
        row.update(schema='paper4-ccpe-bridge-record-1',arm=spec['arm'],attempt=int(attempt),block=spec['block'],actual_date=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).date().isoformat(),pid=os.getpid(),threshold=spec['threshold'],saved_outputs=npz_paths[-1:] if npz_paths else [],not_paper_results=engineering,included_in_statistics=not engineering)
        if case['kind']=='pair' and row['performance_valid']:
            e=row['endpoints_ns'];from .design import endpoint_terms
            parts=endpoint_terms(e['planned_arrival_ns'],e['arrival_ns'],e['old_return_ns'],e['successor_start_ns'],e['successor_end_ns'])
            if sum(parts[k] for k in ['arrival','blocking','ready','service'])!=parts['total']:raise ValueError('Additive endpoint identity')
        return row
    started=time.monotonic();warm=record(dict(kind='full',rep=0));warm['included_in_statistics']=False
    out.with_name(out.stem+'_warmup.json').write_text(json.dumps(warm)+'\n','utf-8')
    if not warm['performance_valid']:raise RuntimeError('Complete warmup failed')
    case_seconds=[]
    with out.open('x',encoding='utf-8') as stream:
        for case in spec['cases']:
            phase=case['kind']+'_rep'+str(case['rep']);npz_paths.clear()
            case_started=time.monotonic();row=record(case);case_seconds.append(time.monotonic()-case_started)
            stream.write(json.dumps(row,allow_nan=False)+'\n');stream.flush()
            if not row['performance_valid']:raise RuntimeError('Quality/behavior failure retained; no implicit retry')
    out.with_name(out.stem+'_process.json').write_text(json.dumps(dict(elapsed_seconds=time.monotonic()-started,case_seconds=case_seconds,identity=identity,search_affinity=sorted(os.sched_getaffinity(0)),module_file=faiss.__file__,manifest_sha256=sha(path),records_sha256=sha(out)))+'\n','utf-8')
if __name__=='__main__':run(*sys.argv[1:])
