"""Describe selected complete-process data; no bootstrap, p-value or imputation."""
from pathlib import Path
from collections import Counter
import argparse,csv,hashlib,json,math,statistics
from .design import ARMS,paired_ratio,select_attempt,endpoint_terms
from .run_local import validity
def describe_ratios(values):
    return dict(n=len(values),missing_of_12=12-len(values),geometric_ratio=math.exp(statistics.mean(math.log(v) for v in values)) if values else None,below=sum(v<1 for v in values),above=sum(v>1 for v in values),ties=sum(v==1 for v in values),minimum=min(values) if values else None,maximum=max(values) if values else None)
def write_csv(path,rows,fields=None):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--results',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    m=json.loads(a.manifest.read_text('utf-8'))
    if m.get('status')!='FROZEN' or m.get('schema')!='paper4-ccpe-bridge-frozen-1':raise ValueError('Formal frozen manifest only')
    if a.output.exists():raise ValueError('Supply a new analysis directory')
    manifest_sha=hashlib.sha256(a.manifest.read_bytes()).hexdigest()
    tasks={t['task_id']:t for t in m['tasks']};processes=[];formal=[];missing=[];sources=[];attempt_rows=[]
    metrics=['old_wall_ns','latency_plan_ns','latency_actual_ns','arrival_lateness_ns','old_blocking_ns','ready_gap_ns','service_ns']
    for panel in m['panels']:
        folder=a.results/panel['panel_id'];attempts=[]
        for i in [0,1]:
            receipt=folder/('attempt_'+str(i))/'receipt.json'
            if receipt.exists():
                saved=json.loads(receipt.read_text('utf-8'))
                if saved.get('manifest_sha256')!=manifest_sha:raise ValueError('Attempt manifest mismatch')
                attempts.append(saved)
                attempt_rows.extend(saved['results'])
        selected=select_attempt(attempts) if attempts else None
        for task in [t for t in m['tasks'] if t['panel_id']==panel['panel_id']]:
            if selected is None or task['task_id'] not in selected['valid_tasks']:
                missing.append(dict(task_id=task['task_id'],panel_id=panel['panel_id'],status='missing_or_invalid_in_selected_attempt'));continue
            file=folder/('attempt_'+str(selected['attempt']))/(task['task_id']+'.jsonl')
            process_file=file.with_name(file.stem+'_process.json')
            process_receipt=json.loads(process_file.read_text('utf-8'))
            if process_receipt.get('manifest_sha256')!=manifest_sha:
                raise ValueError('Process manifest mismatch')
            records_sha=hashlib.sha256(file.read_bytes()).hexdigest()
            if process_receipt.get('records_sha256')!=records_sha:raise ValueError('Saved records differ from process receipt')
            if not validity(file,len(task['cases'])):raise ValueError('Selected task is not a complete valid process')
            rows=[json.loads(s) for s in file.read_text('utf-8').splitlines() if s.strip()]
            for row in rows:
                if row['task_id']!=task['task_id'] or row['attempt']!=selected['attempt'] or row.get('not_paper_results') or not row.get('included_in_statistics'):raise ValueError('Foreign/engineering record in formal data')
                for k in ['panel_id','block','module','state','dataset','nprobe','nq','arm','kind','threshold']:
                    if row[k]!=task[k]:raise ValueError('Frozen condition mismatch '+k)
                if task['kind']=='pair':
                    e=row['endpoints_ns'];v=endpoint_terms(e['planned_arrival_ns'],e['arrival_ns'],e['old_return_ns'],e['successor_start_ns'],e['successor_end_ns'])
                    if sum(v[k] for k in ['arrival','blocking','ready','service'])!=v['total']:raise ValueError('Endpoint identity')
                    for term,key in [('arrival','arrival_lateness_ns'),('blocking','old_blocking_ns'),('ready','ready_gap_ns'),('service','service_ns'),('total','latency_plan_ns')]:
                        if row[key]!=v[term]:raise ValueError('Stored endpoint term differs from timestamps: '+key)
                formal.append(row)
            proc={k:task[k] for k in ['task_id','panel_id','block','module','dataset','nprobe','nq','state','arm','kind']};proc['attempt']=selected['attempt']
            proc.update({metric:statistics.median(r[metric] for r in rows) if all(r.get(metric) is not None for r in rows) else None for metric in metrics});processes.append(proc)
            sources.append(dict(path=str(file),sha256=records_sha))
    if not processes and not attempt_rows:raise ValueError('No formal run evidence; no measurements to analyze')
    conditions=sorted({tuple(t[k] for k in ['module','dataset','nprobe','nq','state']) for t in tasks.values()});contrasts=[];summary=[];means=[];differences=[];absolute=[]
    for condition in conditions:
        meta=dict(zip(['module','dataset','nprobe','nq','state'],condition));select=lambda rows:[r for r in rows if all(r[k]==v for k,v in meta.items())]
        ps=select(processes);rs=select(formal)
        for arm in ARMS:
            for kind,metric in [('pair','latency_plan_ns'),('full','old_wall_ns')]:
                values=[r[metric] for r in ps if r['arm']==arm and r['kind']==kind]
                absolute.append(dict(**meta,arm=arm,kind=kind,metric=metric,n=len(values),geometric_ms=math.exp(statistics.mean(math.log(v) for v in values))/1e6 if values else None,block_values_ms=json.dumps([v/1e6 for v in values])))
            pairs=[r for r in rs if r['arm']==arm and r['kind']=='pair']
            means.append(dict(**meta,arm=arm,records=len(pairs),
                              old_natural_completions=sum(r['old_status']=='complete' for r in pairs),
                              no_overlap=sum(not r['overlap'] for r in pairs),
                              late_arrivals=sum(r['arrival_lateness_ns']>0 for r in pairs),
                              **{k[:-3]+'_ms':statistics.mean(r[k] for r in pairs)/1e6 if pairs else None for k in metrics[1:]}))
        for denominator in ['n3_default','outer16_default','n0_default']:
            numerator_rows=[r for r in rs if r['kind']=='pair' and r['arm']=='n3_global_direct']
            denominator_rows=[r for r in rs if r['kind']=='pair' and r['arm']==denominator]
            def panels(rows):
                return {(r['panel_id'],r['attempt']) for r in rows}
            paired=panels(numerator_rows) & panels(denominator_rows)
            included=[[r for r in rows if (r['panel_id'],r['attempt']) in paired]
                      for rows in (numerator_rows,denominator_rows)]
            differences.append(dict(**meta,numerator='n3_global_direct',denominator=denominator,
                                    matched_blocks=len(paired),records_per_arm=len(included[0]),
                                    **{k[:-3]+'_ms':(statistics.mean(r[k] for r in included[0]) -
                                                      statistics.mean(r[k] for r in included[1]))/1e6 if paired else None
                                       for k in metrics[1:]}))
            for kind,metric in [('pair','latency_plan_ns'),('full','old_wall_ns')]:
                values=[]
                for block in range(1,13):
                    planned=next(t for t in tasks.values() if all(t[k]==v for k,v in meta.items()) and t['block']==block)
                    pair={r['arm']:r for r in ps if r['block']==block and r['kind']==kind}
                    num=pair.get('n3_global_direct'); den=pair.get(denominator)
                    value=None
                    if num and den:
                        value=paired_ratio(dict(num,value=num[metric]),dict(den,value=den[metric]))
                        values.append(value)
                    contrasts.append(dict(**meta,kind=kind,metric=metric,denominator=denominator,block=block,
                                          panel_id=planned['panel_id'],attempt=(num or den or {}).get('attempt'),ratio=value))
                summary.append(dict(**meta,kind=kind,metric=metric,numerator='n3_global_direct',denominator=denominator,**describe_ratios(values)))
    a.output.mkdir(parents=True)
    process_fields=['task_id','panel_id','block','module','dataset','nprobe','nq','state','arm','kind','attempt',*metrics]
    write_csv(a.output/'process_medians.csv',processes,process_fields)
    for name,rows in [('block_comparisons',contrasts),('comparison_summary',summary),('additive_means_ms',means),('additive_differences_ms',differences),('absolute_centers',absolute)]:write_csv(a.output/(name+'.csv'),rows)
    (a.output/'all_attempts.json').write_text(json.dumps(attempt_rows,indent=2)+'\n','utf-8')
    (a.output/'missing.json').write_text(json.dumps(missing,indent=2)+'\n','utf-8')
    (a.output/'analysis_receipt.json').write_text(json.dumps(dict(status='ANALYZED_SELECTED_FORMAL_RECORDS' if processes else 'ATTEMPTED_WITHOUT_VALID_PROCESS',all_attempt_status_counts=Counter(r['status'] for r in attempt_rows),processes=len(processes),formal_records=len(formal),missing_tasks=len(missing),planned_tasks=768,summary_rows=len(summary),sources=sources,resampling=False,new_p_values=False),indent=2)+'\n','utf-8')
    print(json.dumps(dict(processes=len(processes),records=len(formal),missing=len(missing),summary_rows=len(summary))))
if __name__=='__main__':main()
