"""Local panels only. Default lists the plan and starts no search or network work."""
from pathlib import Path
import argparse,datetime,json,os,platform,subprocess,sys,time
from .design import candidate,select_attempt
from .prepare import validated_freeze, sha

def validity(path,required):
    try:
        rows=[json.loads(s) for s in path.read_text('utf-8').splitlines() if s.strip()]
        return len(rows)==required and {r['rep'] for r in rows}==set(range(required)) and len({r['kind'] for r in rows})==1 and all(r['performance_valid'] and not r['synthetic'] for r in rows)
    except (OSError,ValueError,KeyError):return False

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',type=Path);p.add_argument('--output',type=Path);p.add_argument('--panel');p.add_argument('--all',action='store_true');p.add_argument('--technical-retry',help='Objective technical reason for a single incomplete panel, recorded verbatim');a=p.parse_args()
    if a.manifest is None:
        print(json.dumps(candidate(),indent=2));return
    if platform.system()!='Linux':raise SystemExit('Actual local Linux run required')
    m=validated_freeze(a.manifest, verify_evidence=True);root=a.manifest.resolve().parent
    frozen_sha=sha(a.manifest)
    if not a.output or bool(a.panel)==bool(a.all):p.error('Choose --panel ID or --all plus --output NEW_DIRECTORY')
    if a.technical_retry and not a.panel:p.error('Technical retry must name one incomplete panel')
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    panels=[p for p in m['panels'] if a.all or p['panel_id']==a.panel]
    if not panels:raise ValueError('Unknown panel')
    ledger=out/'ledger.jsonl';env=os.environ.copy()
    env['PYTHONPATH']=os.pathsep.join([str((root/m['runtime']['python_path']).resolve()),str(Path(__file__).resolve().parents[1])])
    env['LD_LIBRARY_PATH']=str((root/m['runtime']['library_path']).resolve())+os.pathsep+env.get('LD_LIBRARY_PATH','')
    def append(row):
        with ledger.open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
    for panel in panels:
        folder=out/panel['panel_id'];folder.mkdir(exist_ok=True)
        if any(folder.glob('attempt_*/scientific_failure_stop.json')):
            raise SystemExit('Paused for recorded scientific/behavior failure; inspect and version the repair')
        attempts=[]
        for index in [0,1]:
            receipt=folder/('attempt_'+str(index))/'receipt.json'
            if receipt.exists():
                saved=json.loads(receipt.read_text('utf-8'))
                if saved.get('manifest_sha256')!=frozen_sha:
                    raise ValueError('Retained attempt belongs to a different frozen manifest')
                attempts.append(saved)
        selected=select_attempt(attempts) if attempts else None
        if selected and selected['complete']:continue
        if attempts and not a.technical_retry:continue # Explicit retry only, never repeat silently.
        if a.technical_retry is not None and (not a.technical_retry.strip() or not attempts):
            raise ValueError('A technical retry requires an incomplete first attempt and its objective cause')
        if len(attempts)>=2:continue
        index=len(attempts);dest=folder/('attempt_'+str(index))
        if dest.exists():raise ValueError('Interrupted attempt has no receipt: recover its retained task files explicitly; never overwrite')
        dest.mkdir();tasks=[t for t in m['tasks'] if t['panel_id']==panel['panel_id']]
        results=[];apparatus_stop=False
        for task in tasks:
            target=dest/(task['task_id']+'.jsonl');started=time.time();status='failed';exit_code=None
            command=[sys.executable,'-B','-m','bridge.worker',str(a.manifest.resolve()),task['task_id'],str(target),str(index)]
            with target.with_suffix('.log').open('w',encoding='utf-8') as log:
                try:
                    proc=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=m['watchdog_seconds'])
                    exit_code=proc.returncode
                    if exit_code==0 and validity(target,len(task['cases'])):status='valid'
                except subprocess.TimeoutExpired:status='watchdog_failure_not_latency'
            row=dict(panel_id=panel['panel_id'],task_id=task['task_id'],attempt=index,arm_order=task['arm_order'],started_unix=started,ended_unix=time.time(),exit_code=exit_code,status=status,retry_reason=a.technical_retry if index else None)
            append(row);results.append(row)
            if status=='failed':
                bad=[]
                warm=target.with_name(target.stem+'_warmup.json')
                for file in (warm,target):
                    if file.exists():
                        for line in file.read_text('utf-8').splitlines():
                            try: bad.append(json.loads(line).get('failure_class'))
                            except ValueError: bad.append('unreadable_record')
                if any(x in ('quality_failure','strategy_failure','successor_failure','quiescence_failure','full_guard_expired','missing_quality_validation') for x in bad):
                    (dest/'scientific_failure_stop.json').write_text(json.dumps(row)+'\n','utf-8')
                else:
                    apparatus_stop=True
                break
        receipt=dict(manifest_sha256=frozen_sha,attempt=index,complete=len(results)==len(tasks) and all(r['status']=='valid' for r in results),valid_tasks=[r['task_id'] for r in results if r['status']=='valid'],results=results,retry_reason=a.technical_retry if index else None)
        (dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n','utf-8');attempts.append(receipt)
        chosen=select_attempt(attempts);(folder/'selected_attempt.json').write_text(json.dumps(chosen,indent=2)+'\n','utf-8')
        print(json.dumps(dict(panel_id=panel['panel_id'],complete=receipt['complete'],attempt=index)),flush=True)
        if apparatus_stop:raise SystemExit('Execution paused: worker failed before valid output; inspect retained log before technical recovery')
        if (dest/'scientific_failure_stop.json').exists():raise SystemExit('Affected execution paused: scientific/behavior failure retained; inspect before any new version')
    print('Local selection complete; missing conditions remain explicit in selected_attempt receipts.')
if __name__=='__main__':main()
