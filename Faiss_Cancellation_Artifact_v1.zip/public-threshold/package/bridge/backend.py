"""Adapter for R1 plus external C/P; only public distance threshold changes."""
import ctypes

class CallbackBridge:
    def __init__(self,path):
        self.lib=ctypes.CDLL(str(path));l=self.lib
        l.cb_error.restype=ctypes.c_char_p;l.cb_identity.restype=ctypes.c_char_p
        l.cb_begin.argtypes=[ctypes.c_int64,ctypes.c_int];l.cb_end.argtypes=[ctypes.c_uint64];l.cb_generation.restype=ctypes.c_uint64
        self.identity=l.cb_identity().decode()
        if not self.identity.startswith('paper4-ccpe-external-1;'):raise ValueError('Wrong external callback ABI')
    def check(self,value):
        if value:raise RuntimeError(self.lib.cb_error().decode())
    def begin(self,deadline,persistent):
        self.check(self.lib.cb_begin(deadline,int(persistent)));return self.lib.cb_generation()
    def end(self,g):self.check(self.lib.cb_end(g))
    def enter(self):self.check(self.lib.cb_enter_search())
    def leave(self):self.check(self.lib.cb_leave_search())

class Backend:
    synthetic=False
    state_semantics='external_request_C/P'
    def __init__(self,index,module,callback,helper,producer_cpu,identity):
        self.index=index;self.module=module;self.callback=callback;self.helper=helper;self.producer_cpu=producer_cpu
        self.clock_identity=helper.identity;self.artifact_identity=identity;self.generation=None
    def now_ns(self):return self.helper.now_ns()
    def prepare(self,task):
        self.before_mode=self.index.parallel_mode;self.before_threshold=self.module.cvar.distance_compute_blas_threshold
        self.rep=task['current_case']['rep'];self.module.cvar.distance_compute_blas_threshold=task['cell']['threshold']
        if task['current_case']['kind']!='full':self.helper.prepare(self.producer_cpu)
    def set_branch_policy(self,value):
        if value!='default':raise ValueError('Research coarse-only branch control is not present')
    def set_subcall(self,i):pass
    def schedule(self,target):self.helper.start(target,self.rep,0)
    def receive(self):return self.helper.take()
    def begin(self,deadline,state,api):
        if api!='absolute' or state not in ['C','P'] or self.generation is not None:raise ValueError('External absolute C/P contract')
        self.generation=self.callback.begin(deadline,state=='P')
        return self.generation,dict(deadline_ns=deadline,already_expired=self.now_ns()>=deadline,contract='external_absolute_C/P')
    def end(self,generation):
        if generation!=self.generation:raise ValueError('Generation mismatch')
        self.callback.end(generation);self.generation=None
        # The successor retains the historical native0/default contract.
        self.module.cvar.distance_compute_blas_threshold=128000
    def search(self,queries,k,mode):
        self.index.parallel_mode=mode;self.callback.enter()
        try:return self.index.search(queries,k)
        finally:self.callback.leave()
    def finish(self):
        try:
            if self.generation is not None:self.end(self.generation)
        finally:
            self.helper.finish();self.index.parallel_mode=getattr(self,'before_mode',self.index.parallel_mode)
            if hasattr(self,'before_threshold'):self.module.cvar.distance_compute_blas_threshold=self.before_threshold
    def trace(self):return dict(observation='unobserved_public_internal_trace',events=None,lost=None)
