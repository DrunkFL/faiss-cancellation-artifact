"""Bind configuration, private build, historical inputs and Linux qualification."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
from .design import candidate, engineering_tasks
from .build import ARCHIVE_SHA, R1_SOURCE_SHA, verify_r1_source

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    with Path(path).open("rb") as stream:
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def contract_digest(manifest):
    fields = {k: manifest[k] for k in ("runtime", "resources", "inputs", "identity_files")}
    return hashlib.sha256(json.dumps(fields, sort_keys=True).encode()).hexdigest()


def validate_references(root, inputs, expected):
    for item in expected:
        key = f"{item['nprobe']}/{item['nq']}"
        path = root / inputs[item["dataset"]]["references"][key]
        if sha(path) != item["sha256"]:
            raise ValueError(f"Historical reference mismatch: {item['dataset']}/{key}")


def resolve_config(path):
    path = Path(path).resolve()
    config = json.loads(path.read_text("utf-8"))
    root, runtime = path.parent, config["runtime"]
    files = set()
    for item in json.loads((ROOT/"vendor/historical_input_identities.json").read_text("utf-8")):
        name = {"indexes":"index","bases":"base","queries":"queries"}[item["role"]]
        location = root / config["inputs"][item["dataset"]][name]
        if sha(location) != item["sha256"]:
            raise ValueError(f"Historical input mismatch: {item['dataset']}/{name}")
        files.add(location)
    ref_file = ROOT / "vendor/historical_reference_identities.json"
    validate_references(root, config["inputs"], json.loads(ref_file.read_text("utf-8")))
    for spec in config["inputs"].values():
        files.update(root / name for name in spec["references"].values())

    module = root/runtime["module_file"]
    if module.resolve() != (root/runtime["python_path"]/"faiss/__init__.py").resolve():
        raise ValueError("Python package and module paths disagree")
    mapped = {Path(p).resolve() for p in (root/name for name in runtime["mapped_files"])}
    if not any(re.fullmatch(r"libfaiss\.so(\.\d+)*", p.name) for p in mapped) or (module.parent/"_swigfaiss.so").resolve() not in mapped:
        raise ValueError("Faiss and generic SWIG loaded library paths are required")
    files.update(mapped)
    files.update(module.parent.glob("*.py"))
    files.update(root/runtime[k] for k in ["module_file","callback","helper","build_receipt"])
    receipt_path = root/runtime["build_receipt"]
    built = json.loads(receipt_path.read_text("utf-8"))
    if built.get("status") != "BUILT_NOT_RUNTIME_QUALIFIED" or built.get("native_state_fixture") != "PASS":
        raise ValueError("Private build receipt with native fixture required")
    shipped = { (receipt_path.parent/x["path"]).resolve():x["sha256"] for x in built["files"] }
    for p in mapped | {(root/runtime[k]).resolve() for k in ["module_file","callback","helper"]}:
        if shipped.get(p) != sha(p):
            raise ValueError("Configured binary or module differs from private build: "+str(p))
    if not built.get("dependencies") or not any("openblas" in Path(x["path"]).name.lower() for x in built["dependencies"]):
        raise ValueError("OpenBLAS runtime dependency identity is missing")
    if built.get("source_archive_sha256") != ARCHIVE_SHA or sha(ROOT/"vendor/faiss_v1.15.1_source.tar.gz") != ARCHIVE_SHA or sorted(built["source_changes"]) != sorted(R1_SOURCE_SHA):
        raise ValueError("Private build is missing the pinned upstream and R1-only identity")
    verify_r1_source(built.get("patched_source_sha256"))
    for item in built["dependencies"]:
        p = Path(item["path"])
        if sha(p) != item["sha256"]:
            raise ValueError("Private build dependency changed: "+str(p))
        files.add(p)
    files.update(root/name for name in config.get("extra_identity_files", []))
    for directory in ["bridge", "v3tools", "native"]:
        files.update(p for p in (ROOT/directory).glob("*") if p.suffix in {".py",".cpp",".h"})
    files.update((ref_file, ROOT/"vendor/historical_input_identities.json", ROOT/"vendor/r1_sync.patch",
                  ROOT/"vendor/faiss_v1.15.1_source.tar.gz"))
    identities = [dict(path=os.path.relpath(p, root).replace(os.sep,"/"), sha256=sha(p))
                  for p in sorted({p.resolve() for p in files})]
    return root, config, identities


def manifest(config_path, status="ENGINEERING_ONLY"):
    root, c, ids = resolve_config(config_path)
    m = candidate()
    resources = c["resources"]
    cpus = resources["search_cpus"] + [resources["producer_cpu"]]
    if len(cpus) != 5 or len(set(cpus)) != 5 or any(type(cpu) != int or not 0 <= cpu < 1024 for cpu in cpus):
        raise ValueError("Four distinct search CPUs and a separate producer required")
    m.update(schema="paper4-ccpe-bridge-frozen-1" if status=="FROZEN" else "paper4-ccpe-bridge-engineering-1",
             status=status, runtime=c["runtime"], resources=resources, inputs=c["inputs"], identity_files=ids)
    m["runtime"]["helper_sha256"] = sha(root/c["runtime"]["helper"])
    return root,m


def check_qualification(root, manifest, path, verify_evidence):
    q = json.loads(path.read_text("utf-8"))
    expected = [t["task_id"] for t in engineering_tasks(candidate()["tasks"])]
    if (q.get("status") != "PASS_BRIDGE_QUALIFICATION" or q.get("contract_digest") != contract_digest(manifest)
            or q.get("engineering_processes") != len(expected)
            or [p["task_id"] for p in q.get("processes", [])] != expected
            or q.get("formal_results") != 0 or not q.get("formal_machine_hours_estimate", 0) > 0):
        raise ValueError("Qualification does not cover the planned conditions, configuration and input identities")
    if verify_evidence:
        evidence = {(root/x["path"]).resolve():x["sha256"] for x in q["evidence_files"]}
        required = [path.parent/"callback_smoke.log"]
        for tid in expected:
            required.extend(path.parent/(tid+suffix) for suffix in (".jsonl","_warmup.json","_process.json"))
        if not set(p.resolve() for p in required) <= evidence.keys():
            raise ValueError("Qualification evidence is incomplete")
        for p, digest in evidence.items():
            if sha(p) != digest:
                raise ValueError("Qualification evidence changed: "+str(p))


def validated_freeze(path, verify_evidence=False):
    path = Path(path).resolve()
    m = json.loads(path.read_text("utf-8"))
    if m.get("status") != "FROZEN" or m.get("schema") != "paper4-ccpe-bridge-frozen-1":
        raise ValueError("Formal run requires the new frozen protocol")
    if any(m.get(k) != v for k,v in candidate().items() if k not in {"schema","status"}):
        raise ValueError("Frozen schedule differs from candidate")
    q = path.parent/m["qualification_file"]
    if sha(q) != m["qualification_sha256"]:
        raise ValueError("Frozen qualification receipt changed")
    check_qualification(path.parent, m, q, verify_evidence)
    return m


def main():
    p=argparse.ArgumentParser()
    p.add_argument('config',type=Path)
    p.add_argument('--qualification',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    root,m=manifest(a.config,'FROZEN')
    if a.output.resolve().parent != root:
        raise ValueError("Frozen manifest must share the supplied configuration root")
    check_qualification(root,m,a.qualification.resolve(),True)
    m.update(qualification_sha256=sha(a.qualification),qualification_file=os.path.relpath(a.qualification,root),
             prior_results_seen="Old A/CPU4/Q known; new formal bridge results unseen",
             statistical_policy="12 matched process-median block ratios; descriptive centers/directions/ranges; no new p-values or resampling")
    with a.output.open("x", encoding="utf-8") as stream:
        json.dump(m,stream,ensure_ascii=False,indent=2)
        stream.write("\n")
    print(json.dumps(m["counts"]))


if __name__=="__main__":
    main()
