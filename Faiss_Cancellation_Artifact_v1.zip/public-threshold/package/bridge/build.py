"""Private local Linux build; reads the bundled pinned archive, never downloads."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,platform,shutil,subprocess,sys,tarfile
ROOT=Path(__file__).resolve().parents[1]
ARCHIVE_SHA='6dac2ea4b53c592236bf5f71103c5a18d2ccdaffd8c7a45bd720b811847c4c7b'
# Matched against the accepted R1 build receipt and its two archived files.
R1_SOURCE_SHA = {
    "faiss/impl/AuxIndexStructures.cpp": "09ef856feedde7153ac7129d72b08bebaa1150cf84b665a6a4cc4cf2cba00c02",
    "faiss/impl/AuxIndexStructures.h": "26dd63b9d74ec67f5aaaa69c50ecc7a5e168d3b5620adb81a2454cb44bdbb4a8",
}


def verify_r1_source(actual):
    if actual != R1_SOURCE_SHA:
        raise ValueError("Patched source differs from the two accepted R1 files")


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def assemble_python(src, module):
    module.mkdir(parents=True)
    for name in ("__init__.py", "loader.py", "class_wrappers.py", "gpu_wrappers.py", "extra_wrappers.py",
                 "array_conversions.py", "swigfaiss.py", "_swigfaiss.so", "__init__.pyi", "py.typed"):
        shutil.copyfile(src/name, module/name)
    shutil.copytree(src/"contrib", module/"contrib")


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--jobs',type=int,default=2);a=p.parse_args()
    if platform.system()!='Linux':raise SystemExit('Linux build only; no Windows build qualification is asserted')
    out=a.output.resolve()
    if out.exists():raise SystemExit('Supply a new private build directory')
    archive=ROOT/'vendor/faiss_v1.15.1_source.tar.gz'
    if sha(archive)!=ARCHIVE_SHA:raise ValueError('Pinned source archive mismatch')
    out.mkdir(parents=True);commands=[]
    def run(command):
        commands.append([str(x) for x in command]);r=subprocess.run(commands[-1],cwd=out,capture_output=True,text=True)
        (out/('build_step_'+str(len(commands))+'.log')).write_text(r.stdout+'\n'+r.stderr,'utf-8')
        if r.returncode:raise RuntimeError('Build failed; see '+str(out))
    with tarfile.open(archive) as t:
        for m in t.getmembers():
            q=PurePosixPath(m.name)
            if q.is_absolute() or '..' in q.parts or m.issym() or m.islnk():raise ValueError('Unsafe archive member')
        t.extractall(out,filter='data')
    tree=next(out.glob('faiss-*'));run(['patch','-p1','--batch','--forward','-i',ROOT/'vendor/r1_sync.patch','-d',tree])
    differences={}
    with tarfile.open(archive) as t:
        for m in t.getmembers():
            if m.isfile():
                rel=PurePosixPath(m.name).relative_to(tree.name)
                digest=sha(tree/str(rel))
                if hashlib.sha256(t.extractfile(m).read()).hexdigest()!=digest:
                    differences[str(rel)]=digest
    verify_r1_source(differences)
    build=out/'build'
    run(['cmake','-S',tree,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DFAISS_ENABLE_GPU=OFF','-DFAISS_ENABLE_PYTHON=ON','-DBUILD_TESTING=OFF','-DBUILD_SHARED_LIBS=ON','-DFAISS_OPT_LEVEL=generic','-DFAISS_ENABLE_SVS=OFF','-DFAISS_ENABLE_EXTRAS=OFF','-DFAISS_ENABLE_MKL=OFF','-DBLA_VENDOR=OpenBLAS','-DBLA_SIZEOF_INTEGER=4','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DPython_EXECUTABLE='+sys.executable,'-DCMAKE_BUILD_RPATH_USE_ORIGIN=ON'])
    run(['cmake','--build',build,'--target','swigfaiss','--parallel',str(a.jobs)])
    module=out/'python/faiss'
    assemble_python(build/'faiss/python', module)
    compiler=os.environ.get('CXX','c++');native=ROOT/'native'
    run([compiler,'-std=c++17','-O2','-pthread',native/'test_state.cpp','-o',out/'test_state']);run([out/'test_state'])
    run([compiler,'-std=c++17','-O3','-fPIC','-shared','-pthread',native/'MeasureHelper.cpp','-o',out/'libmeasure_helper.so'])
    run([compiler,'-std=c++20','-O3','-fPIC','-shared','-pthread','-I'+str(tree),native/'ExternalCallback.cpp','-L'+str(build/'faiss'),'-lfaiss','-Wl,-rpath,'+str(build/'faiss'),'-o',out/'libexternal_callback.so'])
    files = list((build/'faiss').glob('libfaiss.so*')) + list(module.glob('*.py')) + [
        module/'_swigfaiss.so', out/'libmeasure_helper.so', out/'libexternal_callback.so']
    dependencies = set()
    private_files = {p.resolve() for p in files}
    ldd_env = dict(os.environ, LD_LIBRARY_PATH=str(build/'faiss')+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''))
    for binary in [module/'_swigfaiss.so', out/'libexternal_callback.so', out/'libmeasure_helper.so', build/'faiss/libfaiss.so']:
        result = subprocess.run(['ldd', str(binary)], check=True, capture_output=True, text=True, env=ldd_env)
        (out/(binary.name+'.ldd.txt')).write_text(result.stdout,'utf-8')
        if 'not found' in result.stdout:
            raise ValueError('Unresolved dependency for '+str(binary))
        for line in result.stdout.splitlines():
            name = line.split('=>')[-1].strip().split(' (')[0]
            p = Path(name)
            if p.is_absolute() and p.resolve() not in private_files:
                dependencies.add(p.resolve())
    if not any('openblas' in p.name.lower() for p in dependencies):
        raise ValueError('LP64 OpenBLAS dependency was not found in the private build')
    receipt=dict(status='BUILT_NOT_RUNTIME_QUALIFIED',source_archive_sha256=ARCHIVE_SHA,source_changes=sorted(differences),patched_source_sha256=differences,commands=commands,files=[dict(path=str(x.relative_to(out)),sha256=sha(x)) for x in files],dependencies=[dict(path=str(p),sha256=sha(p)) for p in sorted(dependencies)],python=sys.version,platform=platform.platform(),python_path=str((out/'python').resolve()),library_path=str((build/'faiss').resolve()),native_state_fixture='PASS',official_wheel=False,research_branch_events=False)
    (out/'build_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n','utf-8');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
