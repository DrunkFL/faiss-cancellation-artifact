"""Finite local Linux qualification; engineering rows never become paper results."""
from pathlib import Path
import argparse,json,os,platform,statistics,subprocess,sys,time
from .prepare import manifest,sha,contract_digest
from .design import engineering_tasks
from .run_local import validity
def main():
    p=argparse.ArgumentParser();p.add_argument('config',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if platform.system()!='Linux':raise SystemExit('Actual Linux qualification required')
    root,m=manifest(a.config);out=a.output.resolve()
    if out.exists():raise ValueError('New qualification directory required')
    if not set(m['resources']['search_cpus']+[m['resources']['producer_cpu']]).issubset(os.sched_getaffinity(0)):raise ValueError('Declared CPUs are unavailable')
    out.mkdir(parents=True);env=os.environ.copy();env['PYTHONPATH']=str(root/m['runtime']['python_path'])+os.pathsep+str(Path(__file__).resolve().parents[1]);env['LD_LIBRARY_PATH']=str(root/m['runtime']['library_path'])+os.pathsep+env.get('LD_LIBRARY_PATH','')
    env['PYTHONOPTIMIZE']='0'
    test=subprocess.run([sys.executable,'-B','-m','bridge.smoke',str(a.config.resolve())],env=env,capture_output=True,text=True,timeout=120)
    (out/'callback_smoke.log').write_text(test.stdout+'\n'+test.stderr,'utf-8')
    if test.returncode:raise RuntimeError('Callback/parameter smoke failed; see retained log')
    # All eight conditions' direct candidates plus simple baseline checks in the
    # long p100 P/C panels. One formal-like row per process, warmup remains separate.
    formal_tasks=m['tasks']
    chosen=engineering_tasks(formal_tasks)
    m['tasks']=chosen;m.update(status='ENGINEERING_ONLY',measurement_role='engineering_excluded_from_paper_results')
    engineering=root/(out.name+'_engineering_manifest.json')
    if engineering.exists():raise ValueError('Engineering manifest exists')
    engineering.write_text(json.dumps(m,indent=2)+'\n','utf-8');processes=[]
    for t in chosen:
        target=out/(t['task_id']+'.jsonl');started=time.monotonic()
        with target.with_suffix('.log').open('w',encoding='utf-8') as log:
            result=subprocess.run([sys.executable,'-B','-m','bridge.worker',str(engineering),t['task_id'],str(target),'0'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
        if result.returncode or not validity(target,1):raise RuntimeError('Qualification process failed; no formal measurement permitted: '+t['task_id'])
        elapsed=time.monotonic()-started
        case_seconds=json.loads(target.with_name(target.stem+'_process.json').read_text('utf-8'))['case_seconds'][0]
        processes.append(dict(task_id=t['task_id'],kind=t['kind'],elapsed_seconds=elapsed,case_seconds=case_seconds))
    # Estimate startup + complete warmup once, then the planned number of cases.
    # Coverage is uneven across arms; use the median by kind as a planning estimate.
    estimated = {}
    for kind, reps in [('pair',8),('full',4)]:
        estimated[kind] = statistics.median(p['elapsed_seconds'] + (reps-1)*p['case_seconds']
                                            for p in processes if p['kind']==kind)
    machine_hours = sum(estimated[t['kind']] for t in formal_tasks)/3600
    files=[engineering,*out.glob('*.json'),*out.glob('*.jsonl'),*out.glob('*.npz'),*out.glob('*.log')]
    receipt=dict(status='PASS_BRIDGE_QUALIFICATION',contract_digest=contract_digest(m),formal_machine_hours_estimate=machine_hours,estimate_method='26 engineering processes; startup + warmup once, measured case time scaled to planned repetitions; median by kind; excludes failures, retries, build and transfer',engineering_processes=len(chosen),processes=processes,formal_results=0,branch_evidence='source_prediction_only',evidence_files=[dict(path=os.path.relpath(x,root).replace('\\','/'),sha256=sha(x)) for x in files])
    (out/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n','utf-8');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
