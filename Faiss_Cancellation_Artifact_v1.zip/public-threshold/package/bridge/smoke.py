"""Actual-interface correctness example; generated tiny vectors are not paper data."""
from pathlib import Path
import ctypes,json,os,subprocess,sys
from .backend import CallbackBridge,Backend
from v3tools.measurement_helper import MeasurementHelper,verify_no_faiss_dependencies
def main(config_path):
    path=Path(config_path).resolve();m=json.loads(path.read_text('utf-8'));root=path.parent;r=m['runtime']
    os.sched_setaffinity(0,set(m['resources']['search_cpus']))
    import numpy as np
    import faiss
    if any(hasattr(faiss,n) for n in ['begin_request','set_branch_policy','runtime_identity']):raise ValueError('Research-patched library rejected')
    if Path(faiss.__file__).resolve()!=(root/r['module_file']).resolve():raise ValueError('Wrong module')
    faiss.omp_set_num_threads(4);faiss.cvar.distance_compute_blas_threshold=128000
    callback=CallbackBridge(root/r['callback']);l=callback.lib;l.cb_current_address.restype=ctypes.c_size_t
    before=l.cb_current_address()
    for state in ['C','P']:
        g=callback.begin(0,state=='P');assert l.cb_poll_qualification()==1
        assert l.cb_poll_qualification()==int(state=='P')
        callback.enter()
        try:
            try:callback.end(g)
            except RuntimeError:pass
            else:raise AssertionError('Live restoration accepted')
        finally:callback.leave()
        callback.end(g);assert l.cb_current_address()==before
    helper_path=root/r['helper'];dep=subprocess.run(['ldd',str(helper_path)],capture_output=True,text=True,check=True).stdout
    verify_no_faiss_dependencies(dep)
    import hashlib
    helper=MeasurementHelper(helper_path,hashlib.sha256(helper_path.read_bytes()).hexdigest())
    l.cb_clock_qualification.restype=ctypes.c_int64
    lo=helper.now_ns();middle=l.cb_clock_qualification();hi=helper.now_ns();assert lo<=middle<=hi
    data=np.random.default_rng(2026110501).normal(size=(512,16)).astype('float32');q=data[:8].copy()
    index=faiss.IndexIVFFlat(faiss.IndexFlatL2(16),16,4);index.train(data);index.add(data);index.nprobe=4
    reference=index.search(q,10)
    backend=Backend(index,faiss,callback,helper,m['resources']['producer_cpu'],dict(role='correctness_fixture_not_paper_result'))
    for state in ['C','P']:
        backend.prepare(dict(current_case=dict(kind='full',rep=0),cell=dict(threshold=1000000000)))
        assert faiss.cvar.distance_compute_blas_threshold==1000000000
        g,_=backend.begin(helper.now_ns()+120000000000,state,'absolute')
        output=backend.search(q,10,3);backend.end(g)
        assert faiss.cvar.distance_compute_blas_threshold==128000 and l.cb_current_address()==before
        assert np.allclose(output[0],reference[0],rtol=1e-5,atol=1e-5)
        backend.finish();assert faiss.cvar.distance_compute_blas_threshold==128000
    # Exercise an actual native exception and a healthy successor under the restored singleton.
    backend.prepare(dict(current_case=dict(kind='full',rep=0),cell=dict(threshold=1000000000)))
    g,_=backend.begin(0,'P','absolute')
    try:
        try:backend.search(q,10,3)
        except RuntimeError as exc:
            if 'computation interrupted' not in str(exc):raise
        else:raise AssertionError('Already-expired native call did not interrupt')
    finally:
        backend.end(g)
        backend.finish()
    successor=backend.search(q[:1],10,0)
    if l.cb_current_address()!=before or faiss.cvar.distance_compute_blas_threshold!=128000 or not np.array_equal(successor[1],reference[1][:1]):
        raise ValueError('Native interruption did not restore a healthy successor')
    print(json.dumps(dict(native_exception_successor=True,status='PASS_INTERFACE_CORRECTNESS_FIXTURE',actual_sample_vectors=512,paper_results=False,C_once_P_persistent=True,callback_restore=True,live_restore_rejected=True,threshold_restore=True,helper_no_faiss=True)))
if __name__=='__main__':main(*sys.argv[1:])
