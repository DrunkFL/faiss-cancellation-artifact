"""Single-machine CCPE bridge; importing does not load Faiss or start work."""
