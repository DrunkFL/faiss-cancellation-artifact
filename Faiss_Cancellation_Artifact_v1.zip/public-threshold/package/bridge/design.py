"""132 fixed candidate, technical-attempt selection and descriptive endpoints."""
import random

ARMS=('n0_default','n3_default','n3_global_direct','outer16_default')
def candidate():
    rng=random.Random(2026110501);panels=[];tasks=[]
    conditions=[('B-P',ds,p,nq,'P') for ds,p in [('SIFT75k',16),('SIFT75k',100),('GloVe75k',16)] for nq in [256,2048]]+[('B-C','SIFT75k',p,2048,'C') for p in [16,100]]
    for block in range(1,13):
        order=list(conditions);rng.shuffle(order)
        for position,(module,ds,p,nq,state) in enumerate(order):
            pid=f'{module}_{ds}_p{p}_q{nq}_{state}_b{block:02}'
            arms=[(arm,kind) for arm in ARMS for kind in ['pair','full']];rng.shuffle(arms)
            panels.append(dict(panel_id=pid,block=block,panel_order=position))
            for arm_order,(arm,kind) in enumerate(arms):
                tasks.append(dict(task_id=pid+'_'+arm+'_'+kind,panel_id=pid,block=block,panel_order=position,arm_order=arm_order,module=module,dataset=ds,nprobe=p,nq=nq,state=state,arm=arm,kind=kind,threshold=1000000000 if arm=='n3_global_direct' else 128000,cases=[dict(kind=kind,rep=i) for i in range(8 if kind=='pair' else 4)]))
    return dict(schema='paper4-ccpe-bridge-candidate-1',status='CANDIDATE_NOT_FROZEN',seed=2026110501,panels=panels,tasks=tasks,counts=dict(panels=96,processes=768,pair_records=3072,full_records=1536,formal_records=4608,warmups=768),deadline_ms=20,long_deadline_ms=120000,watchdog_seconds=600,max_attempts=2)

def select_attempt(attempts):
    if not attempts or len(attempts)>2 or [a['attempt'] for a in attempts]!=list(range(len(attempts))):raise ValueError('At most attempts 0 and 1 in order')
    return next((a for a in attempts if a['complete']),attempts[0])

def paired_ratio(a,b):
    for key in ['panel_id','attempt','state','dataset','nprobe','nq']:
        if a.get(key) is None or a.get(key)!=b.get(key):raise ValueError('Unmatched '+key)
    if a['value']<=0 or b['value']<=0:raise ValueError('Positive time required')
    return a['value']/b['value']

def endpoint_terms(planned,arrival,old_return,start,end):
    if not planned<=arrival<=start<=end or old_return>start:raise ValueError('Invalid endpoints or unsafe successor overlap')
    return dict(arrival=arrival-planned,blocking=max(old_return-arrival,0),ready=start-max(arrival,old_return),service=end-start,total=end-planned)

def engineering_tasks(tasks):
    chosen = []
    for task in tasks:
        if task["block"] != 1:
            continue
        long_sift = task["dataset"] == "SIFT75k" and task["nprobe"] == 100 and task["nq"] == 2048
        check_baseline = task["arm"] in ("n0_default", "outer16_default") or (task["state"] == "P" and task["arm"] == "n3_default")
        if task["arm"] == "n3_global_direct" or (long_sift and check_baseline):
            chosen.append(dict(task, cases=[dict(kind=task["kind"], rep=0)]))
    return chosen
