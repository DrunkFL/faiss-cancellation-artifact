"""Post-data block directions for the public-threshold / outer16 comparison.

Only saved process medians are read. Pair and full are different processes.
Usage: python -B scripts/joint_directions.py BLOCK_CSV PROCESS_CSV OUTPUT_CSV
"""
import argparse
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

CONDITION = ("module", "dataset", "nprobe", "nq", "state")
MATCH = (*CONDITION, "denominator", "block", "panel_id", "attempt")
NUMERATOR = "n3_global_direct"
DENOMINATOR = "outer16_default"
METRICS = {"pair": "latency_plan_ns", "full": "old_wall_ns"}
COUNTS = ("both_lower", "response_lower_full_higher",
          "response_higher_full_lower", "both_higher")

def read(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))

def identity(row, fields):
    return tuple(row[f] for f in fields)

def calculate(block_path, process_path, output_path):
    summary_path = Path(block_path).with_name("comparison_summary.csv")
    blocks, processes, summaries = map(read, (block_path, process_path, summary_path))
    selected = [r for r in blocks if r["denominator"] == DENOMINATOR]
    medians = {}
    process_key = (*CONDITION, "block", "panel_id", "attempt", "arm", "kind")
    for row in processes:
        key = identity(row, process_key)
        if key in medians:
            raise ValueError(f"Duplicate process median {key}")
        medians[key] = row
    official = {}
    for row in summaries:
        if row["denominator"] != DENOMINATOR:
            continue
        if row["numerator"] != NUMERATOR or row["metric"] != METRICS.get(row["kind"]):
            raise ValueError("Unexpected numerator or summary metric")
        key = identity(row, CONDITION) + (row["kind"],)
        if key in official:
            raise ValueError(f"Duplicate summary {key}")
        official[key] = row
    paired = defaultdict(dict)
    for row in selected:
        key = identity(row, MATCH)
        kind = row["kind"]
        if kind not in METRICS or row["metric"] != METRICS[kind]:
            raise ValueError(f"Unexpected metric {row}")
        if kind in paired[key]:
            raise ValueError(f"Duplicate block/kind {key}")
        recomputed = []
        for arm in (NUMERATOR, DENOMINATOR):
            pkey = identity(row, CONDITION) + (row["block"], row["panel_id"], row["attempt"], arm, kind)
            if pkey not in medians:
                raise ValueError(f"Missing matched process {pkey}")
            recomputed.append(float(medians[pkey][METRICS[kind]]))
        if any(not math.isfinite(v) or v <= 0 for v in recomputed):
            raise ValueError(f"Nonpositive/nonfinite median {key}")
        ratio = float(row["ratio"])
        replay = recomputed[0] / recomputed[1]
        if not math.isclose(ratio, replay, rel_tol=1e-12, abs_tol=0):
            raise ValueError(f"Ratio mismatch {key}")
        if (ratio < 1, ratio > 1) != (replay < 1, replay > 1):
            raise ValueError(f"Direction mismatch {key}")
        paired[key][kind] = ratio
    grouped = defaultdict(list)
    for key, value in paired.items():
        if set(value) != set(METRICS):
            raise ValueError(f"Unmatched pair/full {key}")
        grouped[key[:len(CONDITION)]].append((key, value))
    if len(selected) != 192 or len(paired) != 96 or len(grouped) != 8:
        raise ValueError("Expected 192 rows, 96 matched blocks and eight conditions")
    output = []
    for condition, values in grouped.items():
        if len(values) != 12 or len({k[6] for k, _ in values}) != 12:
            raise ValueError(f"Missing/duplicate condition blocks {condition}")
        counts = dict.fromkeys(COUNTS, 0)
        ties = 0
        for _, value in values:
            response, full = value["pair"], value["full"]
            if response == 1 or full == 1:
                ties += 1
            else:
                direction = (response > 1) * 2 + (full > 1)
                counts[COUNTS[direction]] += 1
        for kind in METRICS:
            stats = official[condition + (kind,)]
            observed = [v[kind] for _, v in values]
            margin = (sum(v < 1 for v in observed), sum(v > 1 for v in observed), sum(v == 1 for v in observed))
            if margin != tuple(int(stats[k]) for k in ("below", "above", "ties")) or int(stats["n"]) != 12 or int(stats["missing_of_12"]):
                raise ValueError(f"Official margin mismatch {condition} {kind}")
        output.append(dict(zip(CONDITION, condition), numerator=NUMERATOR,
                           denominator=DENOMINATOR, n=12, **counts, ties=ties, unmatched=0))
    output.sort(key=lambda r: (r["state"] != "P", r["dataset"] != "SIFT75k", int(r["nprobe"]), int(r["nq"])))
    dest = Path(output_path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(output)
    receipt = dict(analysis="post-data descriptive joint directions",
                   numerator=NUMERATOR, denominator=DENOMINATOR,
                   selected_rows=len(selected), matched_blocks=len(paired),
                   conditions=len(output), ties=sum(r["ties"] for r in output),
                   unmatched=0, duplicates=0, process_ratios_checked=len(selected),
                   official_margins_checked=len(official),
                   inputs={Path(p).name: hashlib.sha256(Path(p).read_bytes()).hexdigest()
                           for p in (block_path, process_path, summary_path)})
    dest.with_suffix(".json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return output

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("blocks", type=Path)
    parser.add_argument("processes", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    rows = calculate(args.blocks, args.processes, args.output)
    print(f"Verified {sum(r['n'] for r in rows)} matched blocks across {len(rows)} conditions.")
