"""Recompute the six formal tables from the frozen timing evidence and compare every cell."""
import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path


TABLES = (
    "process_medians.csv", "block_comparisons.csv", "comparison_summary.csv",
    "additive_means_ms.csv", "additive_differences_ms.csv", "absolute_centers.csv",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def numeric_equal(left, right):
    if not isinstance(left, (int, float)) or not isinstance(right, (int, float)):
        return False
    return math.isfinite(left) and math.isfinite(right) and math.isclose(left, right, rel_tol=1e-14, abs_tol=1e-12)


def compare_table(saved, actual):
    def read(path):
        with path.open(encoding="utf-8-sig", newline="") as stream:
            return list(csv.reader(stream))
    expected, recomputed = read(saved), read(actual)
    if not expected or len(expected) != len(recomputed) or expected[0] != recomputed[0]:
        raise ValueError(f"Header or number of rows differs in {saved.name}")
    numerical_roundoff = 0
    for row_number, (before, after) in enumerate(zip(expected[1:], recomputed[1:]), start=2):
        if len(before) != len(expected[0]) or len(after) != len(before):
            raise ValueError(f"Column count differs in {saved.name} row {row_number}")
        for column, left, right in zip(expected[0], before, after):
            if left == right:
                continue
            # Only geometric centers use log/exp and may vary by platform libm.
            floating = column in {"geometric_ms", "geometric_ratio"}
            if floating and left and right:
                if numeric_equal(json.loads(left), json.loads(right)):
                    numerical_roundoff += 1
                    continue
            raise ValueError(f"Different {saved.name} row {row_number}, {column}: {left!r}, {right!r}")
    return {"rows": len(expected)-1, "saved_sha256": digest(saved), "recomputed_sha256": digest(actual),
            "byte_identical": saved.read_bytes() == actual.read_bytes(), "numeric_roundoff_cells": numerical_roundoff}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path, help="New output directory")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    batch = root / "public-threshold"
    output = args.output.resolve()
    if output.exists():
        parser.error("Supply a new output directory.")
    subprocess.run([sys.executable, "-B", "-m", "bridge.analyze", "--manifest", str(batch/"frozen.json"),
                    "--results", str(batch/"results"), "--output", str(output)],
                   check=True, cwd=batch/"package")
    report = {name: compare_table(batch/"analysis"/name, output/name) for name in TABLES}
    for name in ("all_attempts.json", "missing.json"):
        if json.loads((batch/"analysis"/name).read_text("utf-8")) != json.loads((output/name).read_text("utf-8")):
            raise ValueError(f"Recomputed {name} differs")
    def receipt(path):
        obj = json.loads(path.read_text("utf-8"))
        # Source paths have machine-specific roots; the remaining three components locate a record.
        for source in obj["sources"]:
            source["path"] = "/".join(source["path"].replace(chr(92), "/").split("/")[-3:])
        return obj
    if receipt(batch/"analysis/analysis_receipt.json") != receipt(output/"analysis_receipt.json"):
        raise ValueError("Recomputed analysis receipt differs")
    (output/"six_table_check.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
